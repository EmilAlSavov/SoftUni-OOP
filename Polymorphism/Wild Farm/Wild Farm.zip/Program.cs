﻿using System;
using Wild_Farm.Core;

namespace Wild_Farm
{
    public class Program
    {
        static void Main(string[] args)
        {
            Engine engine = new Engine();
            engine.Start();
        }
    }
}
